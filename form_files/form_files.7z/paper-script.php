<!DOCTYPE html>
<html lang="en">
    <head>
        <title>
            <script src="vendors/js/jquery.min.js"></script>
        </title>
        
    </head>
    <body>
        <div class="row">
            <h3>Paper setter and script examiner form</h3>
        </div>

        <div class="form-response">
            <span id="paper-script-error-message" class="label label-danger"></span>
            <span id="paper-script-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addPaperScriptField()">+</button>
                <button class="btn btn-default" onclick="removePaperScriptField()">-</button>
            </div>
            <h4>List of the teachers for paper setter and script examiner</h4>
        </div>

        <section class="paper-script-input">
            <div class="row">
                <div id="paper-script-field-1" class="col-md-4"><p class="field-header">Course No</p></div>
                <div id="paper-script-field-2" class="col-md-4"><p class="field-header">Name of teacher</p></div>
                <div id="paper-script-field-3" class="col-md-4"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="paper-script-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>

        <script>

            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------

            var paper_script_cnt = 0;
            function addPaperScriptField()
            {
                if(paper_script_cnt==0)
                    $('#paper-script-submit').css('visibility','visible');
                
                var courseno = $("<textarea class='form-fields course-field' id='crsPaperScript"+paper_script_cnt+"'></textarea>");
                var livecourseno = $("<div class='live-search-list' id='liveCrsPaperScript"+paper_script_cnt+"'></div>");
                $('#paper-script-field-1').append(courseno,livecourseno);
                
                var name = $("<textarea class='form-fields name-field' id='namePaperScript"+paper_script_cnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNamePaperScript"+paper_script_cnt+"'></div>");
                $('#paper-script-field-2').append(name,livename);
                
                var stud_cnt = $("<textarea class='form-fields' id='numOfStdPaperScript"+paper_script_cnt+"'></textarea>");
                $('#paper-script-field-3').append(stud_cnt);

                paper_script_cnt++;
            }

            function removePaperScriptField()
            {
                if(paper_script_cnt > 1)
                {

                    paper_script_cnt--;
                    var $select = $('#crsPaperScript'+paper_script_cnt);
                    $($select).remove();
                    var $select = $('#liveCrsPaperScript'+paper_script_cnt);
                    $($select).remove();
                    var $select = $('#namePaperScript'+paper_script_cnt);
                    $($select).remove();
                    var $select = $('#liveNamePaperScript'+paper_script_cnt);
                    $($select).remove();
                    var $select = $('#numOfStdPaperScript'+paper_script_cnt);
                    $($select).remove();
                }
            }

            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------


            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------


            $(document).ready(function(){

                $('.paper-script-input').on('click','#paper-script-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<paper_script_cnt;$i++){
                        var $courseno = $('#crsPaperScript'+$i).val();
                        var $name = $('#namePaperScript'+$i).val();
                        var $no_of_student = $('#numOfStdPaperScript'+$i).val();
                        if($courseno==''||$name==''||$no_of_student==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#paper-script-error-message').html('All fields are required');
                    }
                    else{
                        $('#paper-script-error-message').html('');

                        for($i=0;$i<paper_script_cnt;$i++){
                            var $courseno = $('#crsPaperScript'+$i).val();
                            var $name = $('#namePaperScript'+$i).val();
                            var $no_of_student = $('#numOfStdPaperScript'+$i).val();
                            $.ajax({
                                url:"db_send_files/paper-script-send.php",
                                method:"POST",
                                data:{crsPaperScript:$courseno, namePaperScript:$name, numOfStdPaperScript:$no_of_student},
                                success:function(data){
                                    $('.paper-script-input').find('textarea').val('');
                                    $('#paper-script-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#paper-script-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.paper-script-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // (1)
            $('.paper-script-input').on('keyup', '.course-field', function() {
                
                var search = $(this).val();

                var selector = $(this).next();

                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_course.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'COURSE' TEXTFIELD INPUT DATA TO THE livesearch_course.php
            
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.paper-script-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            $('.paper-script-input').on('click','.live-course-no',function() {
                var classcontents = $(this).text();
                var destination = $(this).parent().parent().parent().prev();
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------

        </script>
    </body>
</html>
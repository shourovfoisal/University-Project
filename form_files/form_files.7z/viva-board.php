<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <div class="row">
            <h3>Viva board form</h3>
        </div>
        
        <div class="form-response">
            <span id="viva-error-message" class="label label-danger"></span>
            <span id="viva-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addVivaField()">+</button>
                <button class="btn btn-default" onclick="removeVivaField()">-</button>
            </div>
            <h4>List of members of viva board</h4>
        </div>
        
        <section class="viva-input">
            <div class="row">
                <div id="viva-field-1" class="col-md-4"><p class="field-header">Serial number</p></div>
                <div id="viva-field-2" class="col-md-4"><p class="field-header">Name of teacher</p></div>
                <div id="viva-field-3" class="col-md-4"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="viva-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>
        
        <script>
            
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------
            
            
            var vivacnt = 0;
            function addVivaField()
            {
                if(vivacnt==0)
                    $('#viva-submit').css('visibility','visible');
                
                var serial = $("<textarea class='form-fields' id='slViva"+vivacnt+"'></textarea>");
                $('#viva-field-1').append(serial);
                
                var name = $("<textarea class='form-fields name-field' id='nameViva"+vivacnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameViva"+vivacnt+"'></div>")
                $('#viva-field-2').append(name,livename);
                
                var stdcnt = $("<textarea class='form-fields' id='stdsViva"+vivacnt+"'></textarea>");
                $('#viva-field-3').append(stdcnt);

                vivacnt++;
            }

            function removeVivaField()
            {
                if(vivacnt > 1)
                {

                    vivacnt--;
                    var $select = $('#slViva'+vivacnt);
                    $($select).remove();
                    var $select = $('#nameViva'+vivacnt);
                    $($select).remove();
                    var $select = $('#liveNameViva'+vivacnt);
                    $($select).remove();
                    var $select = $('#stdsViva'+vivacnt);
                    $($select).remove();
                }
            }
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------
            
            
            $(document).ready(function(){
                    
                $('.viva-input').on('click','#viva-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<vivacnt;$i++){
                        var $serial = $('#slViva'+$i).val();
                        var $name = $('#nameViva'+$i).val();
                        var $no_of_students = $('#stdsViva'+$i).val();
                        if($serial==''||$name==''||$no_of_students==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#viva-error-message').html('All fields are required');
                    }
                    else{
                        $('#viva-error-message').html('');

                        for($i=0;$i<vivacnt;$i++){
                            var $serial = $('#slViva'+$i).val();
                            var $name = $('#nameViva'+$i).val();
                            var $no_of_students = $('#stdsViva'+$i).val();
                            $.ajax({
                                url:"db_send_files/viva-board-send.php",
                                method:"POST",
                                data:{slViva:$serial, nameViva:$name, stdsViva:$no_of_students},
                                success:function(data){
                                    $('.viva-input').find('textarea').val('');
                                    $('#viva-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#viva-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.viva-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.viva-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
        </script>
    </body>
</html>
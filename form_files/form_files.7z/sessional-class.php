<!DOCTYPE html>
<html lang="en">
    <head>
        <title>
            <script src="vendors/js/jquery.min.js"></script>
        </title>
        
    </head>
    <body>
        <div class="row">
            <h3>Sessional Class Form</h3>
        </div>

        <div class="form-response">
            <span id="class-error-message" class="label label-danger"></span>
            <span id="class-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addClassField()">+</button>
                <button class="btn btn-default" onclick="removeClassField()">-</button>
            </div>
            <h4>List of the teachers for Sessional class</h4>
        </div>
        
        <section class="class-input">
            <div class="row">
                <div id="class-field-1" class="col-md-3"><p class="field-header">Course No</p></div>
                <div id="class-field-2" class="col-md-3"><p class="field-header">Name of teacher</p></div>
                <div id="class-field-3" class="col-md-3"><p class="field-header">Credit</p></div>
                <div id="class-field-4" class="col-md-3"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="class-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>

        <script>

            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------
            
            var classcnt = 0;
            function addClassField()
            {
                if(classcnt==0)
                    $('#class-submit').css('visibility','visible');
                
                var courseno = $("<textarea class='form-fields course-field' id='crsClass"+classcnt+"'></textarea>");
                var livecourseno = $("<div class='live-search-list' id='liveCrsClass"+classcnt+"'></div>");
                $('#class-field-1').append(courseno,livecourseno);
                
                var name = $("<textarea class='form-fields name-field' id='nameClass"+classcnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameClass"+classcnt+"'></div>");
                $('#class-field-2').append(name,livename);
                
                var credit = $("<textarea class='form-fields' id='credClass"+classcnt+"'></textarea>");
                $('#class-field-3').append(credit);
                
                var stud_cnt = $("<textarea class='form-fields' id='numOfStdClass"+classcnt+"'></textarea>");
                $('#class-field-4').append(stud_cnt);

                classcnt++;
            }

            function removeClassField()
            {
                if(classcnt > 1)
                {

                    classcnt--;
                    var $select = $('#crsClass'+classcnt);
                    $($select).remove();
                    var $select = $('#liveCrsClass'+classcnt);
                    $($select).remove();
                    var $select = $('#nameClass'+classcnt);
                    $($select).remove();
                    var $select = $('#liveNameClass'+classcnt);
                    $($select).remove();
                    var $select = $('#credClass'+classcnt);
                    $($select).remove();
                    var $select = $('#numOfStdClass'+classcnt);
                    $($select).remove();
                }
            }

            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------


            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------


            $(document).ready(function(){

                $('.class-input').on('click','#class-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<classcnt;$i++){
                        var $courseno = $('#crsClass'+$i).val();
                        var $name = $('#nameClass'+$i).val();
                        var $credit = $('#credClass'+$i).val();
                        var $no_of_student = $('#numOfStdClass'+$i).val();
                        if($courseno==''||$name==''||$credit==''||$no_of_student==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#class-error-message').html('All fields are required');
                    }
                    else{
                        $('#class-error-message').html('');

                        for($i=0;$i<classcnt;$i++){
                            var $courseno = $('#crsClass'+$i).val();
                            var $name = $('#nameClass'+$i).val();
                            var $credit = $('#credClass'+$i).val();
                            var $no_of_student = $('#numOfStdClass'+$i).val();
                            $.ajax({
                                url:"db_send_files/sessional-class-send.php",
                                method:"POST",
                                data:{crsClass:$courseno, nameClass:$name, credClass:$credit, numOfStdClass:$no_of_student},
                                success:function(data){
                                    $('.class-input').find('textarea').val('');
                                    $('#class-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#class-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.class-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // (1)
            $('.class-input').on('keyup', '.course-field', function() {
                
                var search = $(this).val();

                var selector = $(this).next();

                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_course.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'COURSE' TEXTFIELD INPUT DATA TO THE livesearch_course.php
            
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.class-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            $('.class-input').on('click','.live-course-no',function() {
                var classcontents = $(this).text();
                var destination = $(this).parent().parent().parent().prev();
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
        </script>
    </body>
</html>
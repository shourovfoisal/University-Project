<!DOCTYPE html>
<html lang="en">
    <head>
        <title>
            <script src="vendors/js/jquery.min.js"></script>
        </title>
        
    </head>
    <body>
        <div class="row">
            <h3>Seminer work form</h3>
        </div>

        <div class="form-response">
            <span id="seminer-8th-error-message" class="label label-danger"></span>
            <span id="seminer-8th-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addSeminer8thField()">+</button>
                <button class="btn btn-default" onclick="removeSeminer8thField()">-</button>
            </div>
            <h4>List of the teachers engaged in seminer work for 8th semester</h4>
        </div>

        <section class="seminer-8th-input">
            <div class="row">
                <div id="seminer-8th-field-1" class="col-md-4"><p class="field-header">Course No</p></div>
                <div id="seminer-8th-field-2" class="col-md-4"><p class="field-header">Name of teacher</p></div>
                <div id="seminer-8th-field-3" class="col-md-4"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="seminer-8th-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>

        <script>

            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------

            var seminer_8th_cnt = 0;
            function addSeminer8thField()
            {
                if(seminer_8th_cnt==0)
                    $('#seminer-8th-submit').css('visibility','visible');
                
                var courseno = $("<textarea class='form-fields course-field' id='crsSeminer8th"+seminer_8th_cnt+"'></textarea>");
                var livecourseno = $("<div class='live-search-list' id='liveCrsSeminer8th"+seminer_8th_cnt+"'></div>");
                $('#seminer-8th-field-1').append(courseno,livecourseno);
                
                var name = $("<textarea class='form-fields name-field' id='nameSeminer8th"+seminer_8th_cnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameSeminer8th"+seminer_8th_cnt+"'></div>");
                $('#seminer-8th-field-2').append(name,livename);
                
                var stud_cnt = $("<textarea class='form-fields' id='numOfStdSeminer8th"+seminer_8th_cnt+"'></textarea>");
                $('#seminer-8th-field-3').append(stud_cnt);

                seminer_8th_cnt++;
            }

            function removeSeminer8thField()
            {
                if(seminer_8th_cnt > 1)
                {

                    seminer_8th_cnt--;
                    var $select = $('#crsSeminer8th'+seminer_8th_cnt);
                    $($select).remove();
                    var $select = $('#liveCrsSeminer8th'+seminer_8th_cnt);
                    $($select).remove();
                    var $select = $('#nameSeminer8th'+seminer_8th_cnt);
                    $($select).remove();
                    var $select = $('#liveNameSeminer8th'+seminer_8th_cnt);
                    $($select).remove();
                    var $select = $('#numOfStdSeminer8th'+seminer_8th_cnt);
                    $($select).remove();
                }
            }

            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------


            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------


            $(document).ready(function(){

                $('.seminer-8th-input').on('click','#seminer-8th-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<seminer_8th_cnt;$i++){
                        var $courseno = $('#crsSeminer8th'+$i).val();
                        var $name = $('#nameSeminer8th'+$i).val();
                        var $no_of_student = $('#numOfStdSeminer8th'+$i).val();
                        if($courseno==''||$name==''||$no_of_student==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#seminer-8th-error-message').html('All fields are required');
                    }
                    else{
                        $('#seminer-8th-error-message').html('');

                        for($i=0;$i<seminer_8th_cnt;$i++){
                            var $courseno = $('#crsSeminer8th'+$i).val();
                            var $name = $('#nameSeminer8th'+$i).val();
                            var $no_of_student = $('#numOfStdSeminer8th'+$i).val();
                            $.ajax({
                                url:"db_send_files/seminer-8th-send.php",
                                method:"POST",
                                data:{crsSeminer8th:$courseno, nameSeminer8th:$name, numOfStdSeminer8th:$no_of_student},
                                success:function(data){
                                    $('.seminer-8th-input').find('textarea').val('');
                                    $('#seminer-8th-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#seminer-8th-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------

            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.seminer-8th-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // (1)
            $('.seminer-8th-input').on('keyup', '.course-field', function() {
                
                var search = $(this).val();

                var selector = $(this).next();

                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_course.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'COURSE' TEXTFIELD INPUT DATA TO THE livesearch_course.php
            
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.seminer-8th-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            $('.seminer-8th-input').on('click','.live-course-no',function() {
                var classcontents = $(this).text();
                var destination = $(this).parent().parent().parent().prev();
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
        </script>
    </body>
</html>
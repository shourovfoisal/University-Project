<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <div class="row">
            <h3>Grade sheet verification team form</h3>
        </div>
        
        <div class="form-response">
            <span id="grade-sheet-verify-error-message" class="label label-danger"></span>
            <span id="grade-sheet-verify-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addGradeSheetVerifyField()">+</button>
                <button class="btn btn-default" onclick="removeGradeSheetVerifyField()">-</button>
            </div>
            <h4>List of members of grade-sheet-verify board</h4>
        </div>
        
        <section class="grade-sheet-verify-input">
            <div class="row">
                <div id="grade-sheet-verify-field-1" class="col-md-4"><p class="field-header">Serial number</p></div>
                <div id="grade-sheet-verify-field-2" class="col-md-4"><p class="field-header">Name of teacher</p></div>
                <div id="grade-sheet-verify-field-3" class="col-md-4"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="grade-sheet-verify-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>
        
        <script>
            
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------
            
            
            var grade_sheet_verify_cnt = 0;
            function addGradeSheetVerifyField()
            {
                if(grade_sheet_verify_cnt==0)
                    $('#grade-sheet-verify-submit').css('visibility','visible');
                
                var serial = $("<textarea class='form-fields' id='slGradeSheetVerify"+grade_sheet_verify_cnt+"'></textarea>");
                $('#grade-sheet-verify-field-1').append(serial);
                
                var name = $("<textarea class='form-fields name-field' id='nameGradeSheetVerify"+grade_sheet_verify_cnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameGradeSheetVerify"+grade_sheet_verify_cnt+"'></div>");
                $('#grade-sheet-verify-field-2').append(name,livename);
                
                var stdcnt = $("<textarea class='form-fields' id='stdsGradeSheetVerify"+grade_sheet_verify_cnt+"'></textarea>");
                $('#grade-sheet-verify-field-3').append(stdcnt);
                
                grade_sheet_verify_cnt++;
            }

            function removeGradeSheetVerifyField()
            {
                if(grade_sheet_verify_cnt > 1)
                {

                    grade_sheet_verify_cnt--;
                    var $select = $('#slGradeSheetVerify'+grade_sheet_verify_cnt);
                    $($select).remove();
                    var $select = $('#nameGradeSheetVerify'+grade_sheet_verify_cnt);
                    $($select).remove();
                    var $select = $('#liveNameGradeSheetVerify'+grade_sheet_verify_cnt);
                    $($select).remove();
                    var $select = $('#stdsGradeSheetVerify'+grade_sheet_verify_cnt);
                    $($select).remove();
                }
            }
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------
            
            
            $(document).ready(function(){
                    
                $('.grade-sheet-verify-input').on('click','#grade-sheet-verify-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<grade_sheet_verify_cnt;$i++){
                        var $serial = $('#slGradeSheetVerify'+$i).val();
                        var $name = $('#nameGradeSheetVerify'+$i).val();
                        var $no_of_students = $('#stdsGradeSheetVerify'+$i).val();
                        if($serial==''||$name==''||$no_of_students==''){
                            alert($i+'| serial: '+$serial+' | name: '+$name+' | students: '+$no_of_students);
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#grade-sheet-verify-error-message').html('All fields are required');
                    }
                    else{
                        $('#grade-sheet-verify-error-message').html('');

                        for($i=0;$i<grade_sheet_verify_cnt;$i++){
                            var $serial = $('#slGradeSheetVerify'+$i).val();
                            var $name = $('#nameGradeSheetVerify'+$i).val();
                            var $no_of_students = $('#stdsGradeSheetVerify'+$i).val();
                            $.ajax({
                                url:"db_send_files/grade-sheet-verify-send.php",
                                method:"POST",
                                data:{slGradeSheetVerify:$serial, nameGradeSheetVerify:$name, stdsGradeSheetVerify:$no_of_students},
                                success:function(data){
                                    $('.grade-sheet-verify-input').find('textarea').val('');
                                    $('#grade-sheet-verify-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#grade-sheet-verify-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.grade-sheet-verify-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.grade-sheet-verify-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
        </script>
    </body>
</html>
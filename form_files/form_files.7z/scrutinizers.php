<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <div class="row">
            <h3>Scrutinizer Form</h3>
        </div>

        <div class="form-response">
            <span id="scrut-error-message" class="label label-danger"></span>
            <span id="scrut-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addScrutField()">+</button>
                <button class="btn btn-default" onclick="removeScrutField()">-</button>
            </div>
            <h4>List of members of scrutinizer team</h4>
        </div>

        <section class="scrut-input">
            <div class="row">
                <div id="scrut-field-1" class="col-md-4"><p class="field-header">Serial number</p></div>
                <div id="scrut-field-2" class="col-md-4"><p class="field-header">Name of teacher</p></div>
                <div id="scrut-field-3" class="col-md-4"><p class="field-header">Number of papers</p></div>
            </div>
            <div class="row">
                <button type="button" id="scrut-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>

        <script>


            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------


            var scrutcnt = 0;
            function addScrutField()
            {
                if(scrutcnt==0)
                    $('#scrut-submit').css('visibility','visible');
                
                var serial = $("<textarea class='form-fields' id='slScrut"+scrutcnt+"'></textarea>")
                $('#scrut-field-1').append(serial);
                
                var name = $("<textarea class='form-fields name-field' id='nameScrut"+scrutcnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameScrut"+scrutcnt+"'></div>");
                $('#scrut-field-2').append(name,livename);
                
                var paper_cnt = $("<textarea class='form-fields' id='numOfPprScrut"+scrutcnt+"'></textarea>");
                $('#scrut-field-3').append(paper_cnt);

                scrutcnt++;
            }

            function removeScrutField()
            {
                if(scrutcnt > 1)
                {

                    scrutcnt--;
                    var $select = $('#slScrut'+scrutcnt);
                    $($select).remove();
                    var $select = $('#nameScrut'+scrutcnt);
                    $($select).remove();
                    var $select = $('#liveNameScrut'+scrutcnt);
                    $($select).remove();
                    var $select = $('#numOfPprScrut'+scrutcnt);
                    $($select).remove();
                }
            }
            
            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------


            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------



            $(document).ready(function(){

                $('.scrut-input').on('click','#scrut-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<scrutcnt;$i++){
                        var $serial = $('#slScrut'+$i).val();
                        var $name = $('#nameScrut'+$i).val();
                        var $papers = $('#numOfPprScrut'+$i).val();
                        if($serial==''||$name==''||$papers==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#scrut-error-message').html('All fields are required');
                    }
                    else{

                        $('#scrut-error-message').html('');

                        for($i=0;$i<scrutcnt;$i++){
                            var $serial = $('#slScrut'+$i).val();
                            var $name = $('#nameScrut'+$i).val();
                            var $papers = $('#numOfPprScrut'+$i).val();
                            $.ajax({
                                url:"db_send_files/scrutinizer-send.php",
                                method:"POST",
                                data:{slScrut:$serial, nameScrut:$name, numOfPprScrut:$papers},
                                success:function(data){
                                    $('.scrut-input').find('textarea').val('');
                                    $('#scrut-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#scrut-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------

            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            // SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            $('.scrut-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val();
                
                console.log($(this).siblings());

                var selector = $(this).next();
                
                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.scrut-input').on('click','.live-teacher-name',function() {
                
                var name_of_teacher = $(this).text();
                name_of_teacher = name_of_teacher+"\n"+$(this).parent().next().text();  // Name is joined with status (eg. Professor).
                var destination = $(this).parent().parent().parent().prev();            // Selects the corresponsing textfield.
                $(destination).val(name_of_teacher);                                    // The name is placed into the textfield.
                
                
                
                var no_of_papers = $(this).parent().next().next().text();                // Gets number of papers from hidden list item
                var id_string = $(this).parent().parent().parent().attr('id');           // Gets the id of the div with search results
                var id_no = id_string.substr(id_string.length-1);                        // Last character of id indicates row number
                
                /*
                    The row number is joined with the id of 'Number
                    of papers' to find the corresponsing 'Number of
                    papers' text field.
                */
                var destination_id = '#numOfPprScrut'+id_no;
                
                
                $(destination_id).val(no_of_papers);                                      // Value is inserted into 'Number of papers'
                
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
        </script>
    </body>
</html>
<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>

        <div class="row">
            <h3>Class Test Form</h3>
        </div>

        <div class="form-response">
            <span id="test-error-message" class="label label-danger"></span>
            <span id="test-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addTestField()">+</button>
                <button class="btn btn-default" onclick="removeTestField()">-</button>
            </div>
            <h4>List of the teachers for class test</h4>
        </div>
        
        <section class="test-input">
            <div class="row">
                <div id="test-field-1" class="col-md-3"><p class="field-header">Course No</p></div>
                <div id="test-field-2" class="col-md-3"><p class="field-header">Name of teacher</p></div>
                <div id="test-field-3" class="col-md-3"><p class="field-header">Number of test</p></div>
                <div id="test-field-4" class="col-md-3"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="test-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>
          
        <script>
            
            
            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------
            
            
            var testcnt = 0;
            function addTestField()
            {
                if(testcnt==0)
                    $('#test-submit').css('visibility','visible');
                
                
                // form-fields IS USED FOR CSS STYLING OF THE TEXTFIELDS
                // course-field IS USED FOR LIVE SEARCH
                // crsTest IS USED FOR NUMBERING THE TEXTFIELD FOR (FUTURE DELETION OF THE FIELD) AND (AJAX DATA SEND) PURPOSES
                var courseno = $("<textarea class='form-fields course-field' id='crsTest"+testcnt+"'></textarea>");
                var livecourseno = $("<div class='live-search-list' id='liveCrsTest"+testcnt+"'></div>");
                $('#test-field-1').append(courseno,livecourseno);
                
                var name = $("<textarea class='form-fields name-field' id='nameTest"+testcnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameTest"+testcnt+"'></div>");
                $('#test-field-2').append(name,livename);
                
                var nooftest = $("<textarea class='form-fields' id='noOfTest"+testcnt+"'></textarea>");
                $('#test-field-3').append(nooftest);
                
                var stud_cnt = $("<textarea class='form-fields' id='numOfStdTest"+testcnt+"'></textarea>");
                $('#test-field-4').append(stud_cnt);

                testcnt++;
            }

            function removeTestField()
            {
                if(testcnt > 1)
                {
                    testcnt--;
                    var $select = $('#crsTest'+testcnt);
                    $($select).remove();
                    var $select = $('#liveCrsTest'+testcnt);
                    $($select).remove();
                    var $select = $('#nameTest'+testcnt);
                    $($select).remove();
                    var $select = $('#liveNameTest'+testcnt);
                    $($select).remove();
                    var $select = $('#noOfTest'+testcnt);
                    $($select).remove();
                    var $select = $('#numOfStdTest'+testcnt);
                    $($select).remove();
                }
            }
            
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------
            
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------
            
            
            $(document).ready(function(){
                    
                $('.test-input').on('click','#test-submit',function(){
                    
                    // CHECKING IF THERE ARE ANY EMPTY INPUT FIELDS WHILE SUBMITTING
                    
                    var $i;
                    var $isnull = false;

                    for($i=0;$i<testcnt;$i++){
                        var $course_no = $('#crsTest'+$i).val();
                        var $name = $('#nameTest'+$i).val();
                        var $no_of_test = $('#noOfTest'+$i).val();
                        var $no_of_student = $('#numOfStdTest'+$i).val();
                        if($course_no==''||$name==''||$no_of_test==''||$no_of_student==''){
                            $isnull = true;
                            break;
                        }
                    }
                    
                    // IF THERE ARE NO NULL FIELDS, THEN SEND THE INFORMATION TO THE class-test-send.php FILE
                    
                    if($isnull){
                        $('#test-error-message').html('All fields are required'); //(1)
                    }
                    else{

                        $('#test-error-message').html('');

                        for($i=0;$i<testcnt;$i++){
                            var $course_no = $('#crsTest'+$i).val();
                            var $name = $('#nameTest'+$i).val();
                            var $no_of_test = $('#noOfTest'+$i).val();
                            var $no_of_student = $('#numOfStdTest'+$i).val();
                            $.ajax({
                                url:"db_send_files/class-test-send.php",
                                method:"POST",
                                data:{crsTest:$course_no, nameTest:$name, noOfTest:$no_of_test, numOfStdTest:$no_of_student},
                                success:function(data){
                                    $('.test-input').find('textarea').val(''); //(2)
                                    
                                    //(3)
                                    $('#test-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#test-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                    // (1) DISPLAYS THE 'All fields are required' MESSAGE
                    // (2) EMPTIFY ALL THE FIELDS AFTER SUBMISSION
                    // (3) DISPLAYS 'Submitted!' MESSAGE FOR A SHORT PERIOD OF TIME
                });
            });
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.test-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // (1)
            $('.test-input').on('keyup', '.course-field', function() {
                
                var search = $(this).val();

                var selector = $(this).next();

                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_course.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'COURSE' TEXTFIELD INPUT DATA TO THE livesearch_course.php
            
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.test-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            $('.test-input').on('click','.live-course-no',function() {
                var classcontents = $(this).text();
                var destination = $(this).parent().parent().parent().prev();
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
            
        </script>
    </body>
</html>
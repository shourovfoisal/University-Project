<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <div class="row">
            <h3>Form for teachers engaged data entry</h3>
        </div>

        <div class="form-response">
            <span id="data-entry-error-message" class="label label-danger"></span>
            <span id="data-entry-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addDataEntryField()">+</button>
                <button class="btn btn-default" onclick="removeDataEntryField()">-</button>
            </div>
            <h4>List of members of data entry team</h4>
        </div>

        <section class="data-entry-input">
            <div class="row">
                <div id="data-entry-field-1" class="col-md-3"><p class="field-header">Name of teacher</p></div>
                <div id="data-entry-field-2" class="col-md-3"><p class="field-header">No. of theory subject</p></div>
                <div id="data-entry-field-3" class="col-md-3"><p class="field-header">No. of sessional subject</p></div>
                <div id="data-entry-field-4" class="col-md-3"><p class="field-header">Number of student</p></div>
            </div>
            <div class="row">
                <button type="button" id="data-entry-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>

        <script>


            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------


            var data_entry_cnt = 0;
            function addDataEntryField()
            {
                if(data_entry_cnt==0)
                    $('#data-entry-submit').css('visibility','visible');
                
                var name = $("<textarea class='form-fields name-field' id='nameDataEntry"+data_entry_cnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameDataEntry"+data_entry_cnt+"'></div>");
                $('#data-entry-field-1').append(name,livename);
                
                var theory_subject_cnt = $("<textarea class='form-fields' id='numOfThSubDataEntry"+data_entry_cnt+"'></textarea>");
                $('#data-entry-field-2').append(theory_subject_cnt);
                
                var sessional_subject_cnt = $("<textarea class='form-fields' id='numOfSessSubDataEntry"+data_entry_cnt+"'></textarea>");
                $('#data-entry-field-3').append(sessional_subject_cnt);
                
                var student_cnt = $("<textarea class='form-fields' id='numOfStdDataEntry"+data_entry_cnt+"'></textarea>");
                $('#data-entry-field-4').append(student_cnt);
                

                data_entry_cnt++;
            }

            function removeDataEntryField()
            {
                if(data_entry_cnt > 1)
                {

                    data_entry_cnt--;
                    var $select = $('#nameDataEntry'+data_entry_cnt);
                    $($select).remove();
                    var $select = $('#liveNameDataEntry'+data_entry_cnt);
                    $($select).remove();
                    var $select = $('#numOfThSubDataEntry'+data_entry_cnt);
                    $($select).remove();
                    var $select = $('#numOfSessSubDataEntry'+data_entry_cnt);
                    $($select).remove();
                    var $select = $('#numOfStdDataEntry'+data_entry_cnt);
                    $($select).remove();
                }
            }
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------


            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------



            $(document).ready(function(){

                $('.data-entry-input').on('click','#data-entry-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<data_entry_cnt;$i++){
                        var $name = $('#nameDataEntry'+$i).val();
                        var $theoritical_subjects = $('#numOfThSubDataEntry'+$i).val();
                        var $sessional_subjects = $('#numOfSessSubDataEntry'+$i).val();
                        var $no_of_students = $('#numOfStdDataEntry'+$i).val();
                        if($name==''||$theoritical_subjects==''||$sessional_subjects==''||$no_of_students==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#data-entry-error-message').html('All fields are required');
                    }
                    else{

                        $('#data-entry-error-message').html('');

                        for($i=0;$i<data_entry_cnt;$i++){
                            var $name = $('#nameDataEntry'+$i).val();
                            var $theoritical_subjects = $('#numOfThSubDataEntry'+$i).val();
                            var $sessional_subjects = $('#numOfSessSubDataEntry'+$i).val();
                            var $no_of_students = $('#numOfStdDataEntry'+$i).val();
                            $.ajax({
                                url:"db_send_files/data-entry-send.php",
                                method:"POST",
                                data:{nameDataEntry:$name, numOfThSubDataEntry:$theoritical_subjects, numOfSessSubDataEntry:$sessional_subjects, numOfStdDataEntry:$no_of_students},
                                success:function(data){
                                    $('.data-entry-input').find('textarea').val('');
                                    $('#data-entry-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#data-entry-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.data-entry-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.data-entry-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------

        </script>
    </body>
</html>
<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <div class="row">
            <h3>Moderation Board Form</h3>
        </div>

        <div class="form-response">
            <span id="mod-error-message" class="label label-danger"></span>
            <span id="mod-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addModField()">+</button>
                <button class="btn btn-default" onclick="removeModField()">-</button>
            </div>
            <h4>List of members of moderation board</h4>
        </div>

        <section class="mod-input">
            <div class="row">
                <div id="mod-field-1" class="col-md-3"><p class="field-header">Serial number</p></div>
                <div id="mod-field-2" class="col-md-3"><p class="field-header">Name of teacher</p></div>
                <div id="mod-field-3" class="col-md-3"><p class="field-header">Designation of teacher</p></div>
                <div id="mod-field-4" class="col-md-3"><p class="field-header">Number of papers</p></div>
            </div>
            <div class="row">
                <button type="button" id="mod-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>

        <script>


            //-------------------------------------------------
            // FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------


            var modcnt = 0;
            function addModField()
            {
                if(modcnt==0)
                    $('#mod-submit').css('visibility','visible');
                
                var serial = $("<textarea class='form-fields' id='slMod"+modcnt+"'></textarea>");
                $('#mod-field-1').append(serial);
                
                var name = $("<textarea class='form-fields name-field' id='nameMod"+modcnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameMod"+modcnt+"'></div>");
                $('#mod-field-2').append(name,livename);
                
                var designation = $("<textarea class='form-fields designation-field' id='desMod"+modcnt+"'></textarea>");
                var livedes = $("<div class='live-search-list' id='liveDesMod"+modcnt+"'></textarea>");
                $('#mod-field-3').append(designation,livedes);
                
                var paper_cnt = $("<textarea class='form-fields' id='numOfPprMod"+modcnt+"'></textarea>");
                $('#mod-field-4').append(paper_cnt);

                modcnt++;
            }

            function removeModField()
            {
                if(modcnt > 1)
                {

                    modcnt--;
                    var $select = $('#slMod'+modcnt);
                    $($select).remove();
                    var $select = $('#nameMod'+modcnt);
                    $($select).remove();
                    var $select = $('#liveNameMod'+modcnt);
                    $($select).remove();
                    var $select = $('#desMod'+modcnt);
                    $($select).remove();
                    var $select = $('#liveDesMod'+modcnt);
                    $($select).remove();
                    var $select = $('#numOfPprMod'+modcnt);
                    $($select).remove();
                }
            }
            
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------


            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------



            $(document).ready(function(){

                $('.mod-input').on('click','#mod-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<modcnt;$i++){
                        var $serial = $('#slMod'+$i).val();
                        var $name = $('#nameMod'+$i).val();
                        var $designation = $('#desMod'+$i).val();
                        var $papers = $('#numOfPprMod'+$i).val();
                        if($serial==''||$name==''||$designation==''||$papers==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#mod-error-message').html('All fields are required');
                    }
                    else{

                        $('#mod-error-message').html('');

                        for($i=0;$i<modcnt;$i++){
                            var $serial = $('#slMod'+$i).val();
                            var $name = $('#nameMod'+$i).val();
                            var $designation = $('#desMod'+$i).val();
                            var $papers = $('#numOfPprMod'+$i).val();
                            $.ajax({
                                url:"db_send_files/moderation-board-send.php",
                                method:"POST",
                                data:{slMod:$serial, nameMod:$name, desMod:$designation, numOfPprMod:$papers},
                                success:function(data){
                                    $('.mod-input').find('textarea').val('');
                                    $('#mod-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#mod-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            // SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            $('.mod-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val();
                
                console.log($(this).siblings());

                var selector = $(this).next();
                
                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            
            
            // SENDS THE 'DESIGNATION' TEXTFIELD INPUT DATA TO THE livesearch_designation.php
            $('.mod-input').on('keyup', '.designation-field', function() {
                
                var search = $(this).val();

                var selector = $(this).next();

                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_designation.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            
            
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.mod-input').on('click','.live-teacher-name',function() {
                
                var name_of_teacher = $(this).text();
                name_of_teacher = name_of_teacher+"\n"+$(this).parent().next().text();  // Name is joined with status (eg. Professor).
                var destination = $(this).parent().parent().parent().prev();            // Selects the corresponsing textfield.
                $(destination).val(name_of_teacher);                                    // The name is placed into the textfield.
                
                
                
                var no_of_papers = $(this).parent().next().next().text();                // Gets number of papers from hidden list item
                var id_string = $(this).parent().parent().parent().attr('id');           // Gets the id of the div with search results
                var id_no = id_string.substr(id_string.length-1);                        // Last character of id indicates row number
                
                /*
                    The row number is joined with the id of 'Number
                    of papers' to find the corresponsing 'Number of
                    papers' text field.
                */
                var destination_id = '#numOfPprMod'+id_no;
                
                
                $(destination_id).val(no_of_papers);                                      // Value is inserted into 'Number of papers'
                
                $($(this).parent().parent()).fadeOut(500);
            });
            
            $('.mod-input').on('click','.live-designation',function() {
                var classcontents = $(this).text();
                var destination = $(this).parent().parent().parent().prev();
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            

        </script>
    </body>
</html>
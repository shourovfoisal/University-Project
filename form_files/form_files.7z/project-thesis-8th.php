<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        
    </head>
    <body>

        <div class="row">
            <h3>Project and thesis form</h3>
        </div>

        <div class="form-response">
            <span id="project-thesis-8th-error-message" class="label label-danger"></span>
            <span id="project-thesis-8th-success-message" class="label label-success"></span>
        </div>

        <div class="row">
            <div class="field-control">
                <button class="btn btn-default" onclick="addProjectThesis8thField()">+</button>
                <button class="btn btn-default" onclick="removeProjectThesis8thField()">-</button>
            </div>
            <h4>List of the teachers engaged with project/thesis work for 8th semester</h4>
        </div>
        
        <section class="project-thesis-8th-input">
            <div class="row">
                <div id="project-thesis-8th-field-1" class="col-md-3"><p class="field-header">Course No</p></div>
                <div id="project-thesis-8th-field-2" class="col-md-3"><p class="field-header">Name of teacher</p></div>
                <div id="project-thesis-8th-field-3" class="col-md-3"><p class="field-header">No. of student (Internal)</p></div>
                <div id="project-thesis-8th-field-4" class="col-md-3"><p class="field-header">No. of student (External)</p></div>
            </div>
            <div class="row">
                <button type="button" id="project-thesis-8th-submit" class="btn btn-primary form-submit">Submit</button>
            </div>
        </section>
        
        <script>
            
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (START)
            //-------------------------------------------------
            
            
            
            var project_thesis_8th_cnt = 0;
            function addProjectThesis8thField()
            {
                if(project_thesis_8th_cnt==0)
                    $('#project-thesis-8th-submit').css('visibility','visible');
                
                
                var courseno = $("<textarea class='form-fields course-field' id='crsProjectThesis8th"+project_thesis_8th_cnt+"'></textarea>");
                var livecourseno = $("<div class='live-search-list' id='liveCrsProjectThesis8th"+project_thesis_8th_cnt+"'></textarea>");
                $('#project-thesis-8th-field-1').append(courseno,livecourseno);
                
                
                var name = $("<textarea class='form-fields name-field' id='nameProjectThesis8th"+project_thesis_8th_cnt+"'></textarea>");
                var livename = $("<div class='live-search-list' id='liveNameProjectThesis8th"+project_thesis_8th_cnt+"'></textarea>");
                $('#project-thesis-8th-field-2').append(name,livename);
                
                
                var stud_cnt_internal = $("<textarea class='form-fields' id='numOfStdIntProjectThesis8th"+project_thesis_8th_cnt+"'></textarea>");
                $('#project-thesis-8th-field-3').append(stud_cnt_internal);
                
                
                var stud_cnt_external = $("<textarea class='form-fields' id='numOfStdExtProjectThesis8th"+project_thesis_8th_cnt+"'></textarea>")
                $('#project-thesis-8th-field-4').append(stud_cnt_external);

                project_thesis_8th_cnt++;
            }

            function removeProjectThesis8thField()
            {
                if(project_thesis_8th_cnt > 1)
                {

                    project_thesis_8th_cnt--;
                    var $select = $('#crsProjectThesis8th'+project_thesis_8th_cnt);
                    $($select).remove();
                    var $select = $('#liveCrsProjectThesis8th'+project_thesis_8th_cnt);
                    $($select).remove();
                    var $select = $('#nameProjectThesis8th'+project_thesis_8th_cnt);
                    $($select).remove();
                    var $select = $('#liveNameProjectThesis8th'+project_thesis_8th_cnt);
                    $($select).remove();
                    var $select = $('#numOfStdIntProjectThesis8th'+project_thesis_8th_cnt);
                    $($select).remove();
                    var $select = $('#numOfStdExtProjectThesis8th'+project_thesis_8th_cnt);
                    $($select).remove();
                }
            }
            
            //-------------------------------------------------
            //  FUNCTIONS FOR ADDING AND REMOVING ROWS (END)
            //-------------------------------------------------
            
            
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (START)
            //---------------------------------------------
            
            
            $(document).ready(function(){
                    
                $('.project-thesis-8th-input').on('click','#project-thesis-8th-submit',function(){

                    var $i;
                    var $isnull = false;

                    for($i=0;$i<project_thesis_8th_cnt;$i++){
                        var $course_no = $('#crsProjectThesis8th'+$i).val();
                        var $name = $('#nameProjectThesis8th'+$i).val();
                        var $no_of_student_internal = $('#numOfStdIntProjectThesis8th'+$i).val();
                        var $no_of_student_external = $('#numOfStdExtProjectThesis8th'+$i).val();
                        if($course_no==''||$name==''||$no_of_student_internal==''||$no_of_student_external==''){
                            $isnull = true;
                            break;
                        }
                    }

                    if($isnull){
                        $('#project-thesis-8th-error-message').html('All fields are required');
                    }
                    else{

                        $('#project-thesis-8th-error-message').html('');

                        for($i=0;$i<project_thesis_8th_cnt;$i++){
                            var $course_no = $('#crsProjectThesis8th'+$i).val();
                            var $name = $('#nameProjectThesis8th'+$i).val();
                            var $no_of_student_internal = $('#numOfStdIntProjectThesis8th'+$i).val();
                            var $no_of_student_external = $('#numOfStdExtProjectThesis8th'+$i).val();
                            $.ajax({
                                url:"db_send_files/project-thesis-8th-send.php",
                                method:"POST",
                                data:{crsProjectThesis8th:$course_no, nameProjectThesis8th:$name, numOfStdIntProjectThesis8th:$no_of_student_internal, numOfStdExtProjectThesis8th:$no_of_student_external},
                                success:function(data){
                                    $('.project-thesis-8th-input').find('textarea').val('');
                                    $('#project-thesis-8th-success-message').fadeIn().html(data);
                                    setTimeout(function(){
                                        $('#project-thesis-8th-success-message').fadeOut('slow');
                                    },2000);
                                }
                            });
                        }
                    }
                });
            });
            
            //---------------------------------------------
            // FUNCTIONS FOR LIVE FORM SUBMISSION (END)
            //---------------------------------------------
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (START)
            //---------------------------------------------
            
            
            // BELOW ARE TWO EVENT HANDLERS - THEY DETECT IF THE USER TYPES SOMETHING IN THE TEXT FIELD
            
            
            // (1)
            $('.project-thesis-8th-input').on('keyup', '.name-field', function() {
                
                var search = $(this).val(); //(2)

                var selector = $(this).next(); //(3)
                
                if($.trim(search.length) == 0) { //(4)
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_teacher.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'NAME' TEXTFIELD INPUT DATA TO THE livesearch_teacher.php
            // (2) READS TEXTFIELD VALUE, ASSIGNS IT TO THE search VARIABLE
            // (3) THE VARIABLE selector SELECTS THE DIV NEXT TO THE TEXTFIELD AS AN OBJECT, FOR INSERTING THE RESULT INTO IT
            // (4) IF THE USER CLEARS THE TEXTFIELD, THE LIVE SEARCH RESULT GETS CLEARED TOO
            
            
            // (1)
            $('.project-thesis-8th-input').on('keyup', '.course-field', function() {
                
                var search = $(this).val();

                var selector = $(this).next();

                if($.trim(search.length) == 0) {
                    selector.html('');
                }
                else
                {
                    $.ajax({
                        type : 'POST',
                        url : 'livesearch_course.php',
                        data : {'search': search},
                        success : function(data) {
                            selector.html(data);
                        }
                    });
                }
                
            });
            // (1) SENDS THE 'COURSE' TEXTFIELD INPUT DATA TO THE livesearch_course.php
            
            
            
            // FILLUP CORRESPONSING INPUT FIELD(s) WHEN A SEARCH RESULT IS CLICKED
            
            $('.project-thesis-8th-input').on('click','.live-teacher-name',function() {
                var classcontents = $(this).text();
                classcontents = classcontents+"\n"+$(this).parent().next().text();
                var destination = $(this).parent().parent().parent().prev();
                //(1)
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            // (1) $(this).parent().parent().parent() THIS IS THE DIRECTORY TO THE LIVE SEARCH RESULT DIV (live-search-list)
            
            $('.project-thesis-8th-input').on('click','.live-course-no',function() {
                var classcontents = $(this).text();
                var destination = $(this).parent().parent().parent().prev();
                $(destination).val(classcontents);
                $($(this).parent().parent()).fadeOut(500);
            });
            
            
            //---------------------------------------------
            //          LIVE SEARCH CODES (END)
            //---------------------------------------------
            
        </script>
    </body>
</html>
Libre Office
=======

Tested to work with Libre Office 3.6.4.3.

Word
====

Tested with Word 2003 and 2010.